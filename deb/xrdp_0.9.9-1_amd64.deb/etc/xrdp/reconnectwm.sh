#!/bin/sh

# Write procedures here you want to execute on reconnect
